create view balance_due_view as
select `ap`.`vendors`.`vendor_name`                                                                           AS `vendor_name`,
       `ap`.`invoices`.`invoice_number`                                                                       AS `invoice_number`,
       `ap`.`invoices`.`invoice_total`                                                                        AS `invoice_total`,
       `ap`.`invoices`.`payment_total`                                                                        AS `payment_total`,
       `ap`.`invoices`.`credit_total`                                                                         AS `credit_total`,
       ((`ap`.`invoices`.`invoice_total` - `ap`.`invoices`.`payment_total`) -
        `ap`.`invoices`.`credit_total`)                                                                       AS `balance_due`
from (`ap`.`vendors`
         join `ap`.`invoices` on ((`ap`.`vendors`.`vendor_id` = `ap`.`invoices`.`vendor_id`)))
where (((`ap`.`invoices`.`invoice_total` - `ap`.`invoices`.`payment_total`) - `ap`.`invoices`.`credit_total`) > 0);

