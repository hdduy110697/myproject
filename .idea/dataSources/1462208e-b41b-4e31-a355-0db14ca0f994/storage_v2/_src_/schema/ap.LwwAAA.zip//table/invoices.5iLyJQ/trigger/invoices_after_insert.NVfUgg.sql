create definer = root@localhost trigger invoices_after_insert
    after INSERT
    on invoices
    for each row
BEGIN
    INSERT INTO invoices_audit VALUES
    (NEW.vendor_id, NEW.invoice_number, NEW.invoice_total, 
    'INSERTED', NOW());
END;

