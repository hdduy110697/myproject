create definer = root@localhost trigger invoices_after_delete
    after DELETE
    on invoices
    for each row
BEGIN
    INSERT INTO invoices_audit VALUES
    (OLD.vendor_id, OLD.invoice_number, OLD.invoice_total, 
    'DELETED', NOW());
END;

