create
    definer = root@localhost procedure test1()
BEGIN
  DECLARE a float default 0;
  DECLARE b float default 0;
DECLARE sum float default 0;
  set a= 102;
  set b=100;
  set sum=a+b;
  select sum;
END;

