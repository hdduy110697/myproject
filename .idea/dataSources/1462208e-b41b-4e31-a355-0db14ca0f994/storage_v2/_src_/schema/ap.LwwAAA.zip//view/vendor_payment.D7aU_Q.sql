create view vendor_payment as
select `ap`.`vendors`.`vendor_id`                 AS `vendor_id`,
       `ap`.`vendors`.`vendor_name`               AS `vendor_name`,
       `ap`.`vendors`.`vendor_address1`           AS `vendor_address1`,
       `ap`.`vendors`.`vendor_address2`           AS `vendor_address2`,
       `ap`.`vendors`.`vendor_city`               AS `vendor_city`,
       `ap`.`vendors`.`vendor_state`              AS `vendor_state`,
       `ap`.`vendors`.`vendor_zip_code`           AS `vendor_zip_code`,
       `ap`.`vendors`.`vendor_phone`              AS `vendor_phone`,
       `ap`.`vendors`.`vendor_contact_last_name`  AS `vendor_contact_last_name`,
       `ap`.`vendors`.`vendor_contact_first_name` AS `vendor_contact_first_name`,
       `ap`.`vendors`.`default_terms_id`          AS `default_terms_id`,
       `ap`.`vendors`.`default_account_number`    AS `default_account_number`
from `ap`.`vendors`;

