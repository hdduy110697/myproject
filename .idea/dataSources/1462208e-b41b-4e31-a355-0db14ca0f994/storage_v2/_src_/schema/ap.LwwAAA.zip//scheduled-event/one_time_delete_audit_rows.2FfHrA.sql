create definer = root@localhost event one_time_delete_audit_rows on schedule
    at '2019-09-12 18:51:31'
    enable
    do
    BEGIN
  DELETE FROM invoices_audit WHERE action_date < NOW() - INTERVAL 1 MONTH LIMIT 100;
END;

