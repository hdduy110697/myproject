create
    definer = root@localhost procedure set_global_count(IN count_var int)
BEGIN
  SET @count = count_var;  
END;

