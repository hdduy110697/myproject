create definer = root@localhost event monthly_delete_audit_rows on schedule
    every '1' MONTH
        starts '2015-06-30 00:00:00'
    enable
    do
    BEGIN
  DELETE FROM invoices_audit WHERE action_date < NOW() - INTERVAL 1 MONTH LIMIT 100;
END;

