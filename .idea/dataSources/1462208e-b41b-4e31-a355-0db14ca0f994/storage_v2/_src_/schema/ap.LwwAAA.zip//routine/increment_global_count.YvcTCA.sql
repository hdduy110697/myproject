create
    definer = root@localhost procedure increment_global_count()
BEGIN
  SET @count = @count + 1;
END;

