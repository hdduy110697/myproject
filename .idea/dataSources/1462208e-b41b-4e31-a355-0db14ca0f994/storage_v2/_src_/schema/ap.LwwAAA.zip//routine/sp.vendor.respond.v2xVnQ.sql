create
    definer = root@localhost procedure `sp.vendor.respond`()
BEGIN
	select vendor_name,vendor_id from vendors order by vendor_id  DESC;
END;

