create
    definer = root@localhost procedure test()
BEGIN
  DECLARE i INT DEFAULT 1;
    DECLARE sum INT DEFAULT 0;

  DECLARE s VARCHAR(400) DEFAULT '';

  -- WHILE loop
  WHILE i < 21 DO
	set sum=sum+i;
    SET i = i + 1;
  END WHILE;
  SET s = CONCAT('tong =', sum);
  SELECT s AS message;
END;

