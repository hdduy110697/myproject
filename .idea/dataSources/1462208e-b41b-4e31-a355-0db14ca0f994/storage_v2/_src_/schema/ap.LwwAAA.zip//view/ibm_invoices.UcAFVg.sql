create view ibm_invoices as
select `ap`.`invoices`.`invoice_number` AS `invoice_number`,
       `ap`.`invoices`.`invoice_date`   AS `invoice_date`,
       `ap`.`invoices`.`invoice_total`  AS `invoice_total`
from `ap`.`invoices`
where (`ap`.`invoices`.`vendor_id` = 34);

