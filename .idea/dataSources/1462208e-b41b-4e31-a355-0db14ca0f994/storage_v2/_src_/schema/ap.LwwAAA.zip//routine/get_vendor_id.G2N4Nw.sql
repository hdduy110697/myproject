create
    definer = root@localhost function get_vendor_id(vendor_name_param varchar(50)) returns int
BEGIN
  DECLARE vendor_id_var INT;
  SELECT vendor_id
  INTO vendor_id_var
  FROM vendors
  WHERE vendor_name = vendor_name_param;
  RETURN(vendor_id_var);
END;

